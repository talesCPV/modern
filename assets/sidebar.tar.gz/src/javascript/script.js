document.getElementById('open_btn').addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('open-sidebar');

    if(!document.getElementById('sidebar').classList.length){

    }

});